/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.SQLException;
import java.sql.DriverManager;
import com.mysql.jdbc.Connection;



public class Conexao {
    private String driver = "com.mysql.jbdc.Driver";
    private String URL = "jdbc:mysql://localhost/CrudJSF";
    private String USER = "root";
    private String SENHA = "root";
    private Connection conn;
    
public Conexao(){
    try{
        Class.forName(driver);
        conn=(Connection)DriverManager.getConnection(URL, USER, SENHA);
    }catch (ClassNotFoundException | SQLException e){
    } 


}
public Connection getConn(){
    return conn;

}
public void fecharConexao(){
    try{
        conn.close();
    } catch (SQLException e){
}
}

}




